# Usage Monitor
API and database for tracking usage analytics.

## Setup

### Create and activate virtual env:
    
    python -m venv .venv
    source .venv/bin/activate

### Install dependencies:
    
    pip install -r requirements.txt

### Start server:
    
    uvicorn app.main:app

## Tests 

### Run unit tests:

    pytest tests/test_unit.py

### Run integration tests:
    
    pytest tests/test_integration.py

### Run load tests:

    locust -f tests/test_load.py
