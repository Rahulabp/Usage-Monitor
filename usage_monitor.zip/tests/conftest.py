import pytest
from fastapi.testclient import TestClient
from mongomock import MongoClient

from app.db import get_db
from app.main import create_app


@pytest.fixture(scope='module')
def mongodb():
    return MongoClient()  

@pytest.fixture(scope='module')  
def db(mongodb):
    return mongodb['test_db']
    
    
@pytest.fixture()
def client(db):
    app = create_app()  
    app.dependency_overrides[get_db] = db
    yield TestClient(app)