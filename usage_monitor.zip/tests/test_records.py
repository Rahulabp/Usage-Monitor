import json
from datetime import datetime

from bson import ObjectId


def test_create_record(client):
    res = client.post("/records", json={
        "_id": str(ObjectId()),
        "user": "person@domain.com",
        "tool": "model_training",
        "timestamp": str(datetime.utcnow())
    })
    assert res.status_code == 200
          
def test_get_records(client): 
    res = client.get("/records")
    assert res.status_code == 200


def test_create_and_get_record(client):
    get_response = client.get("/records")
    existing_records = get_response.json()

    # Given
    payload = {
    "_id": str(ObjectId()),
    "user": "person@domain.com",
    "tool": "model_training",
    "timestamp": str(datetime.utcnow())
    }
    
    response = client.post("/records",  content=json.dumps(payload))

    assert response.status_code == 200
    assert response.json()["user"] == payload["user"]
        
    get_response = client.get("/records")
    assert len(get_response.json()) == len(existing_records) + 1
