"""
Router for Creating and retrieving analysis records
"""
from typing import List

from fastapi import APIRouter

from app.db import init_db
from app.models import AnalysisRecord

db = init_db()
records = db["records"]

router = APIRouter()

@router.get("/records", response_model=List[AnalysisRecord])
async def get_records(user: str = None, tool: str = None):
    """ Endpoint to retrive the created analysis records.
        It supports optional query paramaters: user & tool
    """
    filters = {}
    if user:
        filters["user"] = user
    if tool:
        filters["tool"] = tool

    return list(records.find(filters))


@router.post("/records", response_model=AnalysisRecord)
async def create_record(record: AnalysisRecord):
    """ Endpoint to create record, for given analysis details"""
    record = record.model_dump(exclude_unset=True)
    res = records.insert_one(record)
    # created_record = records.find_one({"_id": res.inserted_id})
    # return AnalysisRecord.parse_obj(created_record, exclude=["_id"])
    return records.find_one({"_id": res.inserted_id})

@router.put("/records/{record_id}", response_model=AnalysisRecord)
async def update_record(record_id: str, record: AnalysisRecord):
    """ Endpoint to update a record based on its ID"""
    existing_record = records.find_one({"_id": record_id})
    if existing_record is None:
        raise HTTPException(status_code=404, detail="Record not found")

    updated_record = record.model_dump(exclude_unset=True)
    records.update_one({"_id": record_id}, {"$set": updated_record})
    return records.find_one({"_id": record_id})

@router.delete("/records/{record_id}", response_model=dict)
async def delete_record(record_id: str):
    """ Endpoint to delete a record based on its ID"""
    deleted_record = records.find_one({"_id": record_id})
    if deleted_record is None:
        raise HTTPException(status_code=404, detail="Record not found")

    records.delete_one({"_id": record_id})
    return {"message": "Record successfully deleted"}