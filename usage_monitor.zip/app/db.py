"""
Database connection
"""

import os

from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()
CLIENT = None

def get_db():
    """To create and retrive the mongodb client """
    global CLIENT
    if CLIENT is None:
        host = os.environ.get("MONGO_HOST")
        port = int(os.environ.get("MONGO_PORT"))
        username = os.environ.get("MONGO_USER")
        password = os.environ.get("MONGO_PASSWORD")
        db = os.environ.get("MONGO_DB")

        CLIENT = MongoClient(
            host=host,
            port=port,
            username=username,
            password=password,
            authSource=db
        )
        return CLIENT[os.environ.get("MONGO_DB")]


def init_db():
    db = get_db()

    if 'records' in db.list_collection_names():
        print("'records' collection already exists. Skipping creation.")
    else:
        # Create collection
        db.create_collection("records")

        # Create indexes
        db.records.create_index([("user", 1)])
        db.records.create_index([("tool", 1)])
        db.records.create_index([("timestamp", 1)])
    return db
