from fastapi import FastAPI

from app.routers import records_router


def create_app() -> FastAPI:
    _app = FastAPI()
    _app.include_router(records_router.router)
    return _app

app = create_app()
